const { Plugin } = window.ItdApp;


const hexToRgbStr = (hex) => {
    if (!hex || typeof hex !== 'string' || hex.length < 4) return '0, 0, 0';
    let c = hex.substring(1).split('');
    if (c.length === 3) c = [c[0], c[0], c[1], c[1], c[2], c[2]];
    const num = parseInt('0x' + c.join(''), 16);
    return [(num >> 16) & 255, (num >> 8) & 255, num & 255].join(', ');
};

const adjustBrightness = (hex, percent) => {
    if (!hex || typeof hex !== 'string') return '#000000';
    let num = parseInt(hex.replace('#', ''), 16);
    let r = Math.max(0, Math.min(255, (num >> 16) + percent));
    let g = Math.max(0, Math.min(255, ((num >> 8) & 0x00FF) + percent));
    let b = Math.max(0, Math.min(255, (num & 0x0000FF) + percent));
    return "#" + (g | (b << 8) | (r << 16)).toString(16).padStart(6, '0');
};


const getSettingsWithPreset = (s) => {
    if (s.preset === 'custom' || !s.preset) return s;
    const base = { ...s, neon_glow: false, remove_borders: false, bg_gradient: '', bg_noise: false };
    
    switch (s.preset) {
        case 'oled': return { ...base, accent: '#ffffff', bg_main: '#000000', bg_sidebar: '#000000', bg_card: '#000000', text_main: '#e7e9ea', glass_opacity: 100, blur_strength: 0, remove_borders: true };
        case 'cyber': return { ...base, accent: '#00f0ff', bg_main: '#050505', bg_sidebar: '#0a0a0a', bg_card: '#121212', text_main: '#f0f0f0', neon_glow: true, glow_intensity: 15, glass_opacity: 90 };
        case 'vapor': return { ...base, accent: '#ff71ce', bg_main: '#2b213a', bg_gradient: 'linear-gradient(to bottom, #2b213a, #1a1a2e)', bg_sidebar: '#241b35', bg_card: '#302b4a', text_main: '#01cdfe', neon_glow: true, glow_intensity: 10, glass_opacity: 80 };
        case 'midnight': return { ...base, accent: '#63e6be', bg_main: '#0f172a', bg_sidebar: '#1e293b', bg_card: '#1e293b', text_main: '#e2e8f0', glass_opacity: 80 };
        case 'forest': return { ...base, accent: '#4ade80', bg_main: '#052e16', bg_sidebar: '#064e3b', bg_card: '#064e3b', text_main: '#ecfdf5', glass_opacity: 75, blur_strength: 30 };
        default: return s;
    }
};

const generateCSS = (rawSettings) => {
    
    if (!rawSettings.enable) return '';
    
    const s = getSettingsWithPreset(rawSettings);
    const accentRGB = hexToRgbStr(s.accent);
    const bgSidebarRGB = hexToRgbStr(s.bg_sidebar);
    
    const opacity = (s.glass_opacity ?? 85) / 100;
    const blur = s.blur_strength ?? 20;
    const radius = s.border_radius ?? 20;
    const backgroundCSS = s.bg_gradient ? `background: ${s.bg_gradient} !important; background-attachment: fixed !important;` : `background-color: ${s.bg_main} !important;`;
    
    const neonCSS = s.neon_glow ? `
        :root { --glow-intensity: ${s.glow_intensity ?? 15}px; }
        .sidebar-nav-item.active, .create-post-submit-btn, .button-primary, .feed-tab.active, .nav-tab-item.active::after, .btn-modern-follow.follow, .ext-card.active {
            box-shadow: 0 0 var(--glow-intensity) rgba(${accentRGB}, 0.6), 0 0 calc(var(--glow-intensity) * 2) rgba(${accentRGB}, 0.3) !important;
        }
    ` : '';

    const borderCSS = s.remove_borders ? `
        .sidebar-nav, .widget-box, .post-container, .app-titlebar, .profile-header-container, .profile-nav-tabs, .create-post-card {
            border-color: transparent !important; box-shadow: none !important;
        }
    ` : '';

    const noiseCSS = s.bg_noise ? `
        body::after {
            content: ""; position: fixed; inset: 0; pointer-events: none; z-index: 0;
            background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http:
            opacity: 0.4;
        }
    ` : '';

    return `
        :root {
            
            --color-primary: ${s.accent} !important;
            --color-primary-rgb: ${accentRGB} !important;
            --color-primary-hover: ${adjustBrightness(s.accent, -20)} !important;
            --color-primary-alpha: rgba(${accentRGB}, 0.1) !important;
            --color-primary-subtle: rgba(${accentRGB}, 0.12) !important;
            --color-primary-glass: rgba(${accentRGB}, 0.2) !important;
            --color-primary-glow: rgba(${accentRGB}, 0.5) !important;
            
            
            --color-background: ${s.bg_main} !important;
            --color-text: ${s.text_main} !important;
            --color-text-secondary: ${adjustBrightness(s.text_main, -80)} !important;
            --color-text-muted: ${adjustBrightness(s.text_main, -120)} !important;
            
            --color-card: ${s.bg_card} !important;
            --color-item-bg: ${s.bg_card} !important;
            --color-input-bg: ${adjustBrightness(s.bg_card, 10)} !important;
            
            --color-border: ${s.remove_borders ? 'transparent' : adjustBrightness(s.bg_card, 20)} !important;
            --color-border-light: ${s.remove_borders ? 'transparent' : adjustBrightness(s.bg_card, 10)} !important;
            
            --glass-bg-rgb: ${bgSidebarRGB} !important;
            --glass-bg: rgba(${bgSidebarRGB}, ${opacity}) !important;
            
            --border-radius-card: ${radius}px !important;
        }

        body, #root, .layout, .content, .settings-content-pane, .settings-sidebar-pane, .settings-modal-new { ${backgroundCSS} }
        
        .sidebar-desktop, .right-sidebar { background-color: transparent !important; }
        
        
        .sidebar-nav, .widget-box, .app-titlebar, .bottom-dock-container .dock-glass-wrapper, .modal-content, .profile-nav-tabs, .mobile-header, .settings-sidebar-pane {
            background-color: rgba(${bgSidebarRGB}, ${opacity}) !important;
            backdrop-filter: blur(${blur}px) !important;
            -webkit-backdrop-filter: blur(${blur}px) !important;
        }

        ${neonCSS}
        ${borderCSS}
        ${noiseCSS}
    `;
};

const applyTheme = (settings) => {
    
    
    Plugin.injectCSS(generateCSS(settings));
};


applyTheme(Plugin.settings.getAll());


Plugin.settings.onChange((newSettings) => {
    applyTheme(newSettings);
});