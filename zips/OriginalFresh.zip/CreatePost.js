const { React, api, hooks } = window.ItdApp;
const { useState, useRef } = React;

const ClipIcon = () => <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m21.44 11.05-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"></path></svg>;
const PaletteIcon = () => <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="13.5" cy="6.5" r=".5" fill="currentColor"></circle><circle cx="17.5" cy="10.5" r=".5" fill="currentColor"></circle><circle cx="8.5" cy="7.5" r=".5" fill="currentColor"></circle><circle cx="6.5" cy="12.5" r=".5" fill="currentColor"></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.555C21.965 6.012 17.461 2 12 2z"></path></svg>;
const PollIcon = () => <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line></svg>;
const CloseIcon = () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>;

const ShellCreatePost = ({ onPostCreated, variant = 'feed' }) => {
    const { currentUser } = hooks.useUser();
    const [text, setText] = useState("");
    const [isSending, setIsSending] = useState(false);
    const [attachments, setAttachments] = useState([]);
    const fileInputRef = useRef(null);

    const encodeMeta = (str) => btoa(unescape(encodeURIComponent(str)));

    const handleFileSelect = async (e) => {
        const files = Array.from(e.target.files);
        if (files.length === 0) return;

        // Эмуляция быстрой реакции интерфейса (опционально можно добавить лоадеры в превью)
        for (const file of files) {
            try {
                const res = await api.uploadFile(file);
                if (res?.data?.id) {
                    // Авто-тегирование для музыки
                    if (file.type.startsWith('audio/')) {
                        const title = file.name.replace(/\.[^/.]+$/, "");
                        const musicTag = `\n[artist:${encodeMeta("Неизвестен")}] [title:${encodeMeta(title)}] #nowkie_music_track`;
                        setText(prev => prev + musicTag);
                    }
                    setAttachments(prev => [...prev, res.data]);
                }
            } catch (err) {
                console.error("Upload failed", err);
            }
        }
        // Сброс инпута, чтобы можно было загрузить тот же файл снова
        if (fileInputRef.current) fileInputRef.current.value = '';
    };

    const submit = async () => {
        if (!text.trim() && attachments.length === 0) return;
        setIsSending(true);
        try {
            const res = await api.createPost(text, attachments.map(a => a.id));
            if (res && !res.error) {
                setText("");
                setAttachments([]);
                if (onPostCreated) onPostCreated(res);
            }
        } catch (e) {
            console.error(e);
        } finally {
            setIsSending(false);
        }
    };

    // Определяем аватар: если есть картинка юзера - ставим её, иначе эмодзи 🤙
    const AvatarDisplay = () => {
        if (currentUser?.avatar && currentUser.avatar.length > 5) {
            return <img src={currentUser.avatar} alt="me" />;
        }
        return "🤙";
    };

    return (
        <div className={`site-create-post ${variant}`}>
            <div className="site-cp-inner">
                <div className="site-cp-avatar">
                    <AvatarDisplay />
                </div>
                <div className="site-cp-content">
                    <textarea 
                        className="site-cp-editor" 
                        placeholder={variant === 'profile' ? "Написать в профиль..." : "Что нового?"}
                        value={text}
                        onInput={(e) => {
                            setText(e.target.value);
                            e.target.style.height = 'auto';
                            e.target.style.height = e.target.scrollHeight + 'px';
                        }}
                        rows={1}
                    />
                    
                    {attachments.length > 0 && (
                        <div className="site-cp-previews">
                            {attachments.map(a => (
                                <div key={a.id} className="site-cp-preview-item">
                                    {a.type?.startsWith('video') ? (
                                        <video src={a.url} />
                                    ) : (
                                        <img src={a.url} alt="att" />
                                    )}
                                    <button 
                                        className="site-cp-remove"
                                        onClick={() => setAttachments(prev => prev.filter(x => x.id !== a.id))}
                                    >
                                        <CloseIcon />
                                    </button>
                                </div>
                            ))}
                        </div>
                    )}

                    <div className="site-cp-toolbar">
                        <div className="site-cp-attach">
                            <input type="file" ref={fileInputRef} hidden multiple onChange={handleFileSelect} />
                            <button className="site-cp-tool-btn" onClick={() => fileInputRef.current.click()} title="Медиа">
                                <ClipIcon />
                            </button>
                            <button className="site-cp-tool-btn" title="Опрос (скоро)">
                                <PollIcon />
                            </button>
                            <button className="site-cp-tool-btn" title="Цвет (скоро)">
                                <PaletteIcon />
                            </button>
                        </div>
                        <button className="site-cp-submit" onClick={submit} disabled={isSending || (!text.trim() && attachments.length === 0)}>
                            {isSending ? "..." : "Опубликовать"}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

if (!window.ItdApp.Components) window.ItdApp.Components = {};
window.ItdApp.Components.ShellCreatePost = ShellCreatePost;