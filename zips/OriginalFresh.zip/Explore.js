const { React, api, hooks, RouterDOM, Virtuoso, Icons } = window.ItdApp;
const { useState, useEffect, useRef, useCallback } = React;
const { Link, useSearchParams } = RouterDOM;

const SearchIcon = () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="11" cy="11" r="8"></circle>
        <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
    </svg>
);

const Explore = () => {
    const [searchParams, setSearchParams] = useSearchParams();
    const queryParam = searchParams.get('q') || "";

    const [searchQuery, setSearchQuery] = useState(queryParam);
    const [data, setData] = useState({ trending: [], clans: [], users: [] });
    const [searchResults, setSearchResults] = useState(null);
    const [isSearching, setIsSearching] = useState(false);
    const [loading, setLoading] = useState(true);

    // Загрузка дефолтных данных (Тренды, Кланы, Рекомендации)
    useEffect(() => {
        const loadDefaultData = async () => {
            setLoading(true);
            try {
                const [trendingRes, clansRes, usersRes] = await Promise.all([
                    api.getExplore(),
                    api.getTopClans(),
                    api.getSuggestions()
                ]);
                setData({
                    trending: trendingRes?.data?.hashtags || [],
                    clans: clansRes?.clans || [],
                    users: usersRes?.users || [],
                });
            } catch (err) {
                console.error(err);
            } finally {
                setLoading(false);
            }
        };
        loadDefaultData();
    }, []);

    // Логика поиска
    useEffect(() => {
        const performSearch = async () => {
            if (searchQuery.trim().length <= 1) {
                setSearchResults(null);
                return;
            }
            setIsSearching(true);
            try {
                const res = await api.search(searchQuery);
                setSearchResults(res?.data || res);
            } catch (e) {
                console.error(e);
            } finally {
                setIsSearching(false);
            }
        };

        const timer = setTimeout(() => {
            if (searchQuery !== queryParam) {
                setSearchParams(searchQuery ? { q: searchQuery } : {}, { replace: true });
            }
            performSearch();
        }, 500);

        return () => clearTimeout(timer);
    }, [searchQuery]);

    // Компонент контента
    const Content = () => {
        // 1. Режим поиска
        if (searchQuery.trim().length > 1) {
            if (isSearching) return <div className="explore-loading">Поиск...</div>;
            if (!searchResults) return null;
            
            const { users, hashtags } = searchResults;
            if (!users?.length && !hashtags?.length) return <div className="explore-empty">Ничего не найдено</div>;

            return (
                <div className="explore-results-list">
                    {}
                    {users?.map(user => (
                        <Link to={`/profile/${user.username}`} key={user.id} className="user-suggestion-item">
                            <div className="suggestion-avatar">
                                {user.avatar ? <img src={user.avatar} /> : "👤"}
                            </div>
                            <div className="suggestion-info">
                                <span className="suggestion-name">
                                    {user.displayName}
                                    {user.verified && <Icons.VerifiedBlue width={16} height={16} style={{marginLeft: 4}} />}
                                </span>
                                <span className="suggestion-handle">@{user.username}</span>
                            </div>
                        </Link>
                    ))}
                    {}
                    {hashtags?.map(tag => (
                        <div key={tag.id} className="explore-item" onClick={() => setSearchQuery('#' + tag.name)}>
                            <div className="explore-item-info">
                                <span className="explore-item-name">#{tag.name}</span>
                                <span className="explore-item-meta">{tag.postsCount} постов</span>
                            </div>
                        </div>
                    ))}
                </div>
            );
        }

        // 2. Дефолтный режим (Тренды, Кого читать, Кланы)
        if (loading) return <div className="explore-loading">Загрузка...</div>;

        return (
            <>
                {}
                <section className="explore-section">
                    <h2 className="explore-section__title">Популярные хэштеги</h2>
                    {data.trending.map((tag, index) => (
                        <div key={tag.id} className="explore-item" onClick={() => setSearchQuery('#' + tag.name)}>
                            <span className="explore-item-rank">{index + 1}</span>
                            <div className="explore-item-info">
                                <span className="explore-item-name">#{tag.name}</span>
                                <span className="explore-item-meta">{tag.postsCount?.toLocaleString()} постов</span>
                            </div>
                        </div>
                    ))}
                </section>

                {}
                <section className="explore-section">
                    <h2 className="explore-section__title">Кого читать</h2>
                    {data.users.map(user => (
                        <Link to={`/profile/${user.username}`} key={user.id} className="user-suggestion-item">
                            <div className="suggestion-avatar">
                                {user.avatar ? <img src={user.avatar} /> : "👤"}
                            </div>
                            <div className="suggestion-info">
                                <div className="suggestion-name-row">
                                    <span className="suggestion-name">{user.displayName}</span>
                                    {user.verified && <Icons.VerifiedBlue width={16} height={16} />}
                                </div>
                                <span className="suggestion-handle">@{user.username}</span>
                                <span className="suggestion-subtext">
                                    {(user.followersCount || 0).toLocaleString()} подписчиков
                                </span>
                            </div>
                        </Link>
                    ))}
                </section>

                {}
                <section className="explore-section" style={{borderBottom: 'none'}}>
                    <h2 className="explore-section__title">Топ кланов</h2>
                    <div className="clans-grid">
                        {data.clans.slice(0, 10).map((clan, index) => (
                            <div key={index} className="explore-clan-badge">
                                <span className="explore-clan-rank">{index + 1}</span>
                                <span>{clan.avatar}</span>
                                <span className="explore-clan-count">{clan.memberCount >= 1000 ? (clan.memberCount/1000).toFixed(1) + 'K' : clan.memberCount}</span>
                            </div>
                        ))}
                    </div>
                </section>
            </>
        );
    };

    return (
        <div className="explore-page-root">
            {}
            <Virtuoso
                style={{ height: '100%', width: '100%' }}
                totalCount={1}                 itemContent={() => (
                    <div className="explore-monolith">
                        <div className="explore-header-container">
                            <div className="search-bar-wrapper">
                                <div className="search-icon-absolute"><SearchIcon /></div>
                                <input 
                                    type="text" 
                                    className="search-input"
                                    placeholder="Поиск пользователей и хэштегов"
                                    value={searchQuery}
                                    onChange={(e) => setSearchQuery(e.target.value)}
                                />
                            </div>
                        </div>
                        <Content />
                        <div style={{height: 20}}></div> {}
                    </div>
                )}
            />
        </div>
    );
};

window.ItdApp.register('Page.Explore', Explore);