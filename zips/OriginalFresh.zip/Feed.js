const { React, api, hooks, RouterDOM, Virtuoso, Icons } = window.ItdApp;
const { useState, useEffect, useMemo, useRef } = React;

const ClipIcon = () => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m21.44 11.05-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"></path></svg>;
const PaletteIcon = () => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="13.5" cy="6.5" r=".5" fill="currentColor"></circle><circle cx="17.5" cy="10.5" r=".5" fill="currentColor"></circle><circle cx="8.5" cy="7.5" r=".5" fill="currentColor"></circle><circle cx="6.5" cy="12.5" r=".5" fill="currentColor"></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.555C21.965 6.012 17.461 2 12 2z"></path></svg>;
const PollIcon = () => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line></svg>;

const ShellCreatePost = ({ onPostCreated }) => {
    const [text, setText] = useState("");
    const [isSending, setIsSending] = useState(false);
    const [attachments, setAttachments] = useState([]);
    const fileInputRef = useRef(null);

    const handleFileSelect = async (e) => {
        const files = Array.from(e.target.files);
        for (const file of files) {
            const res = await api.uploadFile(file);
            if (res?.data?.id) setAttachments(prev => [...prev, res.data]);
        }
    };

    const submit = async () => {
        if (!text.trim() && attachments.length === 0) return;
        setIsSending(true);
        const res = await api.createPost(text, attachments.map(a => a.id));
        if (res && !res.error) {
            setText("");
            setAttachments([]);
            if (onPostCreated) onPostCreated(res);
        }
        setIsSending(false);
    };

    return (
        <div className="site-create-post">
            <div className="site-cp-inner">
                <div className="site-cp-avatar">🤙</div>
                <div className="site-cp-content">
                    <textarea 
                        className="site-cp-editor" 
                        placeholder="Что нового?" 
                        value={text}
                        onInput={(e) => {
                            setText(e.target.value);
                            e.target.style.height = 'auto';
                            e.target.style.height = e.target.scrollHeight + 'px';
                        }}
                    />
                    {attachments.length > 0 && (
                        <div className="site-cp-previews">
                            {attachments.map(a => (
                                <div key={a.id} className="site-cp-preview-item">
                                    <img src={a.url} alt="att" />
                                </div>
                            ))}
                        </div>
                    )}
                    <div className="site-cp-toolbar">
                        <div className="site-cp-attach">
                            <input type="file" ref={fileInputRef} hidden multiple onChange={handleFileSelect} />
                            <button className="site-cp-tool-btn" onClick={() => fileInputRef.current.click()}><ClipIcon /></button>
                            <button className="site-cp-tool-btn"><PaletteIcon /></button>
                            <button className="site-cp-tool-btn"><PollIcon /></button>
                        </div>
                        <button className="site-cp-submit" onClick={submit} disabled={isSending}>
                            Опубликовать
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

const CustomFeedPage = () => {
    const [posts, setPosts] = useState([]);
    const [clans, setClans] = useState([]);
    const [tab, setTab] = useState('popular');
    const [cursor, setCursor] = useState(null);
    const [hasMore, setHasMore] = useState(true);
    const [loading, setLoading] = useState(true);

    const PostCard = window.ItdApp.Components.PostCard;

    const load = async (isInitial = false) => {
        if (isInitial) setLoading(true);
        try {
            const res = await api.getPosts(tab, isInitial ? null : cursor, 20);
            const data = res?.data || res;
            const newPosts = data?.posts || [];
            
            setPosts(prev => isInitial ? newPosts : [...prev, ...newPosts]);
            setCursor(data?.pagination?.nextCursor);
            setHasMore(data?.pagination?.hasMore);

            if (isInitial) {
                const cRes = await api.getTopClans();
                setClans(cRes?.clans || cRes?.data?.clans || []);
            }
        } catch (e) {
            console.error("Feed error:", e);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => { load(true); }, [tab]);

    const Header = useMemo(() => () => (
            <div className="shell-feed-header">
                <window.ItdApp.Components.ShellCreatePost 
                onPostCreated={(p) => setPosts(prev => [p, ...prev])} 
                variant="feed" 
            />
            
            <div className="theme-feed-container">
                <div className="theme-feed-tabs">
                    <button className={tab === 'popular' ? 'active' : ''} onClick={() => setTab('popular')}>Популярное</button>
                    <button className={tab === 'subscribed' ? 'active' : ''} onClick={() => setTab('subscribed')}>Подписки</button>
                </div>

                <div className="theme-clans-section">
                    <h3 className="theme-section-title">Топ кланов</h3>
                    <div className="theme-clans-list">
                        {clans.slice(0, 10).map((c, i) => (
                            <div key={i} className={`theme-clan-badge ${i < 3 ? 'top' : ''}`}>
                                <span className="theme-clan-rank">{i + 1}</span>
                                <span className="theme-clan-avatar">{c.avatar}</span>
                                <span className="theme-clan-count">{Math.round(c.memberCount / 100) / 10}K</span>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    ), [tab, clans]);

    return (
        <div className="shell-page-root">
            {}
            <Virtuoso
                style={{ height: '100%', width: '100%' }}
                data={posts}
                endReached={() => hasMore && load(false)}
                components={{ Header }}
                itemContent={(index, post) => (
                    <div className={`monolith-item ${index === posts.length - 1 ? 'last-item' : ''}`}>
                        <div className="shell-post-wrapper">
                            <PostCard post={post} />
                        </div>
                    </div>
                )}
            />
        </div>
    );
};

window.ItdApp.register('Page.Feed', CustomFeedPage);