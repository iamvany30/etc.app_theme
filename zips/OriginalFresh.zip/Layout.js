const { React, Components, DynamicComponent } = window.ItdApp;

const CustomShell = ({ children }) => {
    return (
        <div className="layout">
            {}
            <DynamicComponent name="Layout.Sidebar" fallback={Components.Sidebar} />
            
            <main className="content">
                {children}
            </main>

            {}
            <div className="shell-legal-footer">
                <a href="#/legal/terms">Условия использования</a>
                <a href="#/legal/privacy">Конфиденциальность</a>
                <a href="#/legal/cookies">Cookies</a>
                <p>© 2026 итд</p>
            </div>

            <DynamicComponent name="Global.Player" fallback={Components.GlobalPlayer} />
        </div>
    );
};

window.ItdApp.register('Layout.MainWrapper', CustomShell);