const { React, api, RouterDOM, Virtuoso, Icons } = window.ItdApp;
const { useState, useEffect, useCallback, useMemo } = React;
const { Link } = RouterDOM;

// Получение иконки и цвета для типа уведомления
const getNotifStyle = (type) => {
    switch (type) {
        case 'like': 
            return { icon: <Icons.IconLikeFilled width={12} height={12} />, cls: 'badge-like', text: 'оценил ваш пост' };
        case 'comment': 
            return { icon: <Icons.IconCommentFilled width={12} height={12} />, cls: 'badge-comment', text: 'прокомментировал ваш пост' };
        case 'reply': 
            return { icon: <Icons.IconCommentFilled width={12} height={12} style={{transform: 'scaleX(-1)'}} />, cls: 'badge-reply', text: 'ответил на ваш комментарий' };
        case 'repost': 
            return { icon: <Icons.IconRepostFilled width={12} height={12} />, cls: 'badge-repost', text: 'сделал репост' };
        case 'follow': 
            return { icon: <Icons.IconUserFilled width={12} height={12} />, cls: 'badge-follow', text: 'подписался на вас' };
        case 'mention': 
            return { icon: <Icons.IconMentionFilled width={12} height={12} />, cls: 'badge-mention', text: 'упомянул вас' };
        default: 
            return { icon: <Icons.IconUserFilled width={12} height={12} />, cls: 'badge-system', text: 'взаимодействовал с вами' };
    }
};

const TimeAgo = ({ dateStr }) => {
    const [text, setText] = useState('');
    
    useEffect(() => {
        const update = () => {
            if (!dateStr) return;
            const diff = Math.floor((new Date() - new Date(dateStr)) / 1000);
            if (diff < 60) setText('только что');
            else if (diff < 3600) setText(`${Math.floor(diff / 60)} минут назад`);
            else if (diff < 86400) setText(`${Math.floor(diff / 3600)} час назад`);
            else setText(new Date(dateStr).toLocaleDateString());
        };
        update();
        const timer = setInterval(update, 60000);
        return () => clearInterval(timer);
    }, [dateStr]);

    return <span className="notif-time">{text}</span>;
};

const NotificationItem = ({ notif }) => {
    const { actor, type, preview, createdAt, read, targetId } = notif;
    const { icon, cls, text } = getNotifStyle(type);

    // Куда ведет клик
    const linkTo = (type === 'follow' || type === 'mention_user') 
        ? `/profile/${actor.username}` 
        : `/post/${targetId}`;

    // Отмечаем как прочитанное при появлении (упрощенно)
    useEffect(() => {
        if (!read && notif.id) {
            // Можно добавить задержку или IntersectionObserver для оптимизации
            api.markBatchRead([notif.id]).catch(() => {});
        }
    }, [notif.id, read]);

    return (
        <Link to={linkTo} className={`notification-item ${!read ? 'unread' : ''}`}>
            <div className="notif-avatar-wrapper">
                <div className="notif-avatar">
                    {actor.avatar ? <img src={actor.avatar} alt="u" /> : "👤"}
                </div>
                <div className={`notif-badge-icon ${cls}`}>
                    {icon}
                </div>
            </div>

            <div className="notif-content">
                <div className="notif-top-line">
                    <span className="notif-user-name">{actor.displayName}</span>
                    <span className="notif-action-text">{text}</span>
                </div>
                {preview && <div className="notif-preview-text">{preview}</div>}
                <TimeAgo dateStr={createdAt} />
            </div>
        </Link>
    );
};

const NotificationsPage = () => {
    const [notifs, setNotifs] = useState([]);
    const [tab, setTab] = useState('all');
    const [loading, setLoading] = useState(true);

    const loadData = useCallback(async () => {
        setLoading(true);
        try {
            const apiTab = tab === 'mentions' ? 'mention' : 'all';
            const res = await api.getNotifications(apiTab);
            const list = res?.notifications || res?.data?.notifications || [];
            setNotifs(list);
            
            // Сброс счетчика в сайдбаре
            if (window.resetNotificationCount) window.resetNotificationCount();
        } catch (e) {
            console.error(e);
        } finally {
            setLoading(false);
        }
    }, [tab]);

    useEffect(() => { loadData(); }, [loadData]);

    const markAllRead = async () => {
        try {
            await api.markAllRead();
            setNotifs(prev => prev.map(n => ({...n, read: true})));
        } catch(e) {}
    };

    // ШАПКА "МОНОЛИТА"
    const Header = useMemo(() => () => (
        <div className="notifications-monolith">
            {}
            <div className="notifications-header">
                <h2 className="notifications-title">Уведомления</h2>
                <button className="mark-read-link" onClick={markAllRead}>Прочитать все</button>
            </div>

            {}
            <div className="notif-tabs">
                <button className={`notif-tab ${tab==='all'?'active':''}`} onClick={()=>setTab('all')}>
                    Все
                </button>
                <button className={`notif-tab ${tab==='mentions'?'active':''}`} onClick={()=>setTab('mentions')}>
                    Упоминания
                </button>
            </div>
        </div>
    ), [tab]);

    return (
        <div className="notifications-page-root">
            {loading && notifs.length === 0 ? (
                <div style={{paddingTop: 20}}>
                    <Header />
                    <div className="notif-loading">Загрузка...</div>
                </div>
            ) : (
                <Virtuoso
                    style={{ height: '100%', width: '100%' }}
                    data={notifs}
                    components={{ Header }}
                    itemContent={(index, notif) => (
                                                <div style={{
                            borderLeft: '1px solid var(--color-border)',
                            borderRight: '1px solid var(--color-border)',
                            backgroundColor: 'var(--color-background)'
                        }}>
                            <NotificationItem notif={notif} />
                        </div>
                    )}
                                        footer={() => (
                        <div style={{
                            height: 20, 
                            borderTop: '1px solid var(--color-border-light)',
                            borderLeft: '1px solid var(--color-border)',
                            borderRight: '1px solid var(--color-border)',
                            borderBottom: '1px solid var(--color-border)',
                            borderRadius: '0 0 24px 24px',
                            backgroundColor: 'var(--color-background)',
                            marginBottom: 20
                        }} />
                    )}
                />
            )}
        </div>
    );
};

window.ItdApp.register('Page.Notifications', NotificationsPage);