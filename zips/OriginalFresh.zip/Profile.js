const { React, api, hooks, RouterDOM, Virtuoso, Icons, Modals, Components } = window.ItdApp;
const { useState, useEffect, useMemo, useRef, useCallback } = React;
const { useParams } = RouterDOM;

const IconCalendar = () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>;
const IconSettings = () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1 0-2.83 2 2 0 0 1 0-2.83l.06.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>;
const IconCamera = () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"></path><circle cx="12" cy="13" r="4"></circle></svg>;

const ProfileCreatePost = ({ onPostCreated, userAvatar }) => {
    // Временная заглушка, в реальности тут должен быть полноценный компонент
    return <Components.CreatePost onPostCreated={onPostCreated} />;
};

const Profile = () => {
    const { username } = useParams();
    const { currentUser, setCurrentUser } = hooks.useUser();
    const { openModal } = hooks.useModal();
    const PostCard = Components.PostCard;

    const [user, setUser] = useState(null);
    const [posts, setPosts] = useState([]);
    const [tab, setTab] = useState('posts');
    const [loading, setLoading] = useState(true);
    const [isFollowing, setIsFollowing] = useState(false);
    
    const isMyProfile = currentUser?.username === username;

    const fetchProfile = useCallback(async () => {
        try {
            const res = await api.getProfile(username);
            const u = res?.user || res;
            if(u) {
                setUser(u);
                setIsFollowing(u.isFollowing);
            }
        } catch(e) { console.error(e); }
    }, [username]);

    const loadPosts = useCallback(async () => {
        setLoading(true);
        try {
            const method = tab === 'posts' ? api.getUserPosts : api.getUserLikedPosts;
            const res = await method(username, null, 50);
            setPosts(res?.posts || res?.data?.posts || []);
        } finally { setLoading(false); }
    }, [username, tab]);

    useEffect(() => { fetchProfile(); loadPosts(); }, [fetchProfile, loadPosts]);

    const toggleFollow = async () => {
        try {
            if(isFollowing) await api.unfollowUser(username);
            else await api.followUser(username);
            setIsFollowing(!isFollowing);
        } catch(e) {}
    };

    const ProfileHeader = useMemo(() => {
        if (!user) return () => <div className="profile-loading">Загрузка профиля...</div>;

        const date = new Date(user.createdAt).toLocaleDateString('ru-RU', {month: 'long', year: 'numeric'});
        
        // ЛОГИКА АВАТАРА: Если длина > 5 символов, считаем ссылкой. Иначе — эмодзи/текст
        const renderAvatar = (avatarUrl) => {
            if (avatarUrl && avatarUrl.length > 5) {
                return <img src={avatarUrl} alt="avatar" />;
            }
            return avatarUrl || "👤";
        };

        return (
            <div className="profile-monolith">
                <div className="profile-banner">
                    {user.banner ? <img src={user.banner} alt="banner" /> : <div className="profile-banner-placeholder" />}
                    {isMyProfile && (
                        <button className="edit-banner-btn" onClick={() => openModal(<Modals.BannerEditorModal />)}>
                            <IconCamera />
                        </button>
                    )}
                </div>

                <div className="profile-header-top">
                    <div className="profile-avatar-wrapper">
                        <div className="profile-avatar">
                            {renderAvatar(user.avatar)}
                        </div>
                        {user.isOnline && <div className="profile-online-badge" />}
                    </div>
                    
                    <div className="profile-actions">
                        {isMyProfile ? (
                            <>
                                <button className="profile-btn" onClick={() => openModal(<Modals.EditProfileModal />)}>
                                    Редактировать
                                </button>
                                <button className="profile-icon-btn" onClick={() => openModal(<Modals.SettingsModal />)}>
                                    <IconSettings />
                                </button>
                            </>
                        ) : (
                            <button className="profile-btn" onClick={toggleFollow} style={{
                                backgroundColor: isFollowing ? 'transparent' : 'var(--color-text)',
                                color: isFollowing ? 'var(--color-text)' : 'var(--color-background)'
                            }}>
                                {isFollowing ? 'Читаю' : 'Читать'}
                            </button>
                        )}
                    </div>
                </div>

                <div className="profile-info">
                    <div className="profile-display-name">
                        {user.displayName}
                        {user.verified && <Icons.VerifiedBlue width={18} height={18} />}
                    </div>
                    <div className="profile-username">@{user.username}</div>
                    
                    {user.bio && <div className="profile-bio">{user.bio}</div>}
                    
                    <div className="profile-meta">
                        <div className="profile-meta-item">
                            <IconCalendar /> Регистрация: {date}
                        </div>
                    </div>

                    <div className="profile-stats">
                        <span className="stat-link"><strong>{user.followingCount || 0}</strong> Подписки</span>
                        <span className="stat-link"><strong>{user.followersCount || 0}</strong> Подписчики</span>
                    </div>
                </div>

                <nav className="profile-tabs">
                    <button className={`profile-tab ${tab==='posts'?'active':''}`} onClick={()=>setTab('posts')}>
                        Посты
                    </button>
                    <button className={`profile-tab ${tab==='likes'?'active':''}`} onClick={()=>setTab('likes')}>
                        Понравившиеся
                    </button>
                </nav>

                {isMyProfile && tab === 'posts' && (
                    <div className="profile-create-post-wrapper">
                                            <window.ItdApp.Components.ShellCreatePost 
                        onPostCreated={(p) => setPosts(prev => [p, ...prev])} 
                        variant="profile" 
                    />
                    </div>
                )}
            </div>
        );
    }, [user, tab, isMyProfile, isFollowing]);

    return (
        <div className="profile-page-root">
            <Virtuoso
                style={{ height: '100%', width: '100%' }}
                data={posts}
                components={{ Header: () => ProfileHeader }}
                itemContent={(index, post) => (
                    <div className={`monolith-item ${index === posts.length - 1 ? 'last-item' : ''}`}>
                        <div className="shell-post-wrapper">
                            <PostCard post={post} />
                        </div>
                    </div>
                )}
            />
        </div>
    );
};

window.ItdApp.register('Page.Profile', Profile);