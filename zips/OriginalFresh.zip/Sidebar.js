const { React, RouterDOM, Icons, api, hooks, Modals } = window.ItdApp;
const { NavLink } = RouterDOM;
const { useState, useEffect } = React;

const Sidebar = () => {
    const { currentUser, setCurrentUser } = hooks.useUser();
    const { openModal } = hooks.useModal();
    const [unread, setUnread] = useState(0);
    const [menuOpen, setMenuOpen] = useState(false);

    useEffect(() => {
        api.getNotificationsCount().then(res => setUnread(res?.count || 0));
        const unsub = window.api.onNotification(() => setUnread(v => v + 1));
        return () => unsub?.removeListener?.();
    }, []);

    const logout = async () => {
        if(confirm('Выйти?')) {
            await api.call('/v1/auth/logout', 'POST');
            setCurrentUser(null);
            window.location.reload();
        }
    };

    if (!currentUser) return null;

    // Функция проверки: эмодзи или ссылка
    const isImageAvatar = (avatar) => avatar && avatar.length > 5;

    return (
        <aside className="theme-sidebar-container">
            <div className="sidebar-top-cluster">
                <div className="shell-logo" onClick={() => window.location.hash = '/'}>ИТД</div>

                <nav className="capsule-pill">
                    <NavLink to="/" className={({isActive})=>`cap-item ${isActive?'active':''}`} title="Лента">
                        <Icons.IconFeed width={22} height={22} />
                    </NavLink>

                    <NavLink to="/explore" className={({isActive})=>`cap-item ${isActive?'active':''}`} title="Поиск">
                        <Icons.IconExplore width={22} height={22} />
                    </NavLink>

                    <NavLink to="/notifications" className={({isActive})=>`cap-item ${isActive?'active':''}`} title="Уведомления">
                        <div className="cap-badge-root">
                            <Icons.IconNotifications width={22} height={22} />
                            {unread > 0 && <span className="cap-badge" />}
                        </div>
                    </NavLink>
                    
                    <NavLink 
                        to={`/profile/${currentUser.username}`} 
                        className={({isActive})=>`cap-item ${isActive?'active':''}`} 
                        title="Профиль"
                    >
                        <Icons.IconProfile width={22} height={22} />
                    </NavLink>
                </nav>
            </div>

            <div className="shell-footer-trigger">
                {menuOpen && (
                    <>
                        <div className="menu-backdrop" onClick={() => setMenuOpen(false)} />
                        <div className="shell-emoji-menu">
                            <button onClick={() => { openModal(<Modals.SettingsModal />); setMenuOpen(false); }}>
                                Настройки
                            </button>
                            <button className="danger" onClick={logout}>
                                Выйти
                            </button>
                        </div>
                    </>
                )}
                
                <div 
                    className={`shell-footer-avatar ${menuOpen ? 'active' : ''}`} 
                    onClick={() => setMenuOpen(!menuOpen)}
                    title="Меню аккаунта"
                >
                    {isImageAvatar(currentUser.avatar) ? (
                        <img src={currentUser.avatar} alt="Me" />
                    ) : (
                        <div className="shell-footer-avatar-placeholder">
                            {currentUser.avatar || "👤"}
                        </div>
                    )}
                </div>
            </div>
        </aside>
    );
};

window.ItdApp.register('Layout.Sidebar', Sidebar);